CREATE TABLE online_sales (
    order_id INT,
    product_id INT,
    amount DECIMAL(10,2),
    order_date DATE
);

-- Insert dummy data
INSERT INTO online_sales VALUES
(1, 101, 200.50, '2023-01-15'),
(2, 102, 150.75, '2023-01-20'),
(3, 103, 300.00, '2023-02-05'),
(4, 104, 120.00, '2023-02-18'),
(5, 105, 180.00, '2023-03-01'),
(6, 101, 220.50, '2023-03-10');

SELECT 
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    SUM(amount) AS total_revenue,
    COUNT(DISTINCT order_id) AS total_orders
FROM 
    online_sales
GROUP BY 
    EXTRACT(YEAR FROM order_date),
    EXTRACT(MONTH FROM order_date)
ORDER BY 
    year, month;

SELECT 
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    SUM(amount) AS total_revenue
FROM 
    online_sales
GROUP BY 
    EXTRACT(YEAR FROM order_date),
    EXTRACT(MONTH FROM order_date)
ORDER BY 
    total_revenue DESC
LIMIT 3;

